THE ISLES OF DARKNESS: QGIS project
===================================

Open IslesMap.qgz in QGIS 3.44 or later. Keep it in the same folder as
IslesofDarkness.gpkg, which holds every layer the project uses:

  Territories    terrain polygons with all territory attributes
  Clans          house holdings (two-stroke boundaries)
  Regions        dissolved regions, used for the region labels
  Ocean          sea zones with harvest, danger and evasion values
  Abyss          the surrounding void
  Castles        castle names, labelled in violet from 1:40,000 inward
  Rivers, Impassable, ClanOwnership

Coordinate system: EPSG:3857.
Labels use Garamond; if that font isn't installed, QGIS substitutes one.

The interactive web edition of this map is built from the same data.
