THE ISLES OF DARKNESS: QGIS project
===================================

Needs QGIS 3.34 or later (free from qgis.org).

FIRST: unzip this folder ("Extract All" on Windows). Opening the project from
inside the zip leaves the data behind, and every layer will show as missing.

Then use whichever of these is easiest:

  1. Double-click IslesMap.qgz
     The full project: layer order, symbology and labels.

  2. Drag IslesofDarkness.gpkg into an open QGIS window
     Every layer arrives already styled; this one file is self-contained.

  3. In QGIS: Project > Open From > GeoPackage > IslesofDarkness.gpkg > IslesMap
     The same project, stored inside the GeoPackage.

preview.png shows what you should see.

Layers (all in IslesofDarkness.gpkg, EPSG:3857):
  Territories   terrain polygons with every territory attribute
  Clans         house holdings (two-stroke boundaries)
  Regions       dissolved regions, used for region labels
  Ocean         sea zones with harvest, danger and evasion values
  Abyss         the surrounding void
  Rivers, Impassable, ClanOwnership, IslesWeb

Labels use Garamond; if it isn't installed, QGIS substitutes a similar font.
